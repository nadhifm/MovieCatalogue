package com.nadhif.moviecatalogue.ui.movie

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nadhif.moviecatalogue.data.CatalogueRepository
import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.utils.Resource

class MovieViewModel @ViewModelInject constructor(
    private val catalogueRepository: CatalogueRepository
) : ViewModel() {

    fun getMovies(): LiveData<Resource<List<Movie>>> = catalogueRepository.getMovies(viewModelScope)

    override fun onCleared() {
        super.onCleared()
        catalogueRepository.cancelJob()
    }
}