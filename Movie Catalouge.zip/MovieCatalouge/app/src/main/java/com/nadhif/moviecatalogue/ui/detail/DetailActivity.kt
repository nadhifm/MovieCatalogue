package com.nadhif.moviecatalogue.ui.detail

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.nadhif.moviecatalogue.databinding.ActivityDetailBinding
import com.nadhif.moviecatalogue.utils.Constants
import com.nadhif.moviecatalogue.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "extra_id"
        const val EXTRA_MOVIE = "extra_movie"
        const val EXTRA_TV_SHOW = "extra_tv_show"
    }

    private lateinit var binding: ActivityDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        val movie = intent.getIntExtra(EXTRA_MOVIE, 0)
        val tvShow = intent.getIntExtra(EXTRA_TV_SHOW, 0)
        if (movie == 1) {
            detailViewModel.getMovies()
            detailViewModel.movie.observe(this, {
                when(it) {
                    is Resource.Loading -> {
                        binding.progressBarDetail.visibility = View.VISIBLE
                    }
                    is Resource.Success -> {
                        val selectedMovie = it.data
                        selectedItem(
                            selectedMovie.title,
                            selectedMovie.overview,
                            selectedMovie.posterPath,
                            selectedMovie.backdropPath,
                            selectedMovie.releaseDate
                        )
                        binding.progressBarDetail.visibility = View.GONE
                    }
                    is Resource.Error -> {
                        Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                        binding.progressBarDetail.visibility = View.GONE
                    }
                }
            })
        }

        if (tvShow == 1) {
            detailViewModel.getTvShows()
            detailViewModel.tvShow.observe(this, {
                when(it) {
                    is Resource.Loading -> {
                        binding.progressBarDetail.visibility = View.VISIBLE
                    }
                    is Resource.Success -> {
                        val selectedMovie = it.data
                        selectedItem(
                            selectedMovie.name,
                            selectedMovie.overview,
                            selectedMovie.posterPath,
                            selectedMovie.backdropPath,
                            selectedMovie.firstAirDate
                        )
                        binding.progressBarDetail.visibility = View.GONE
                    }
                    is Resource.Error -> {
                        Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                        binding.progressBarDetail.visibility = View.GONE
                    }
                }
            })
        }

    }

    private fun selectedItem(title: String?, desc: String?, poster: String?, backdrop: String?, releaseDate: String?) {
        binding.tvTitleDetail.text = title
        binding.tvDesc.text = desc
        binding.tvReleaseDate.text = releaseDate

        val fullBackdropUrl = Constants.IMAGE_URL + backdrop
        Glide.with(this)
                .load(fullBackdropUrl)
                .into(binding.ivPoster2)

        val fullPosterUrl = Constants.IMAGE_URL + poster
        Glide.with(this)
                .load(fullPosterUrl)
                .into(binding.ivPoster1)
    }
}