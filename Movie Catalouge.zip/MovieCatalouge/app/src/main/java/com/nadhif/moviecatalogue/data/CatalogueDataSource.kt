package com.nadhif.moviecatalogue.data

import androidx.lifecycle.LiveData
import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.utils.Resource
import kotlinx.coroutines.CoroutineScope

interface CatalogueDataSource {
    fun getMovies(viewModelScope: CoroutineScope): LiveData<Resource<List<Movie>>>
    fun getTvShows(viewModelScope: CoroutineScope): LiveData<Resource<List<TvShow>>>
    fun cancelJob()
}