package com.nadhif.moviecatalogue.ui.tvshow

import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nadhif.moviecatalogue.data.CatalogueRepository

class TvShowViewModel @ViewModelInject constructor(
    private val catalogueRepository: CatalogueRepository
) : ViewModel() {

    fun getTvShows() = catalogueRepository.getTvShows(viewModelScope)

    override fun onCleared() {
        super.onCleared()
        catalogueRepository.cancelJob()
    }
}