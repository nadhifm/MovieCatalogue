package com.nadhif.moviecatalogue.ui.movie

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nadhif.moviecatalogue.R
import com.nadhif.moviecatalogue.adapter.MovieAdapter
import com.nadhif.moviecatalogue.databinding.FragmentMovieBinding
import com.nadhif.moviecatalogue.ui.detail.DetailActivity
import com.nadhif.moviecatalogue.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MovieFragment : Fragment(R.layout.fragment_movie) {

    private lateinit var binding: FragmentMovieBinding
    private lateinit var movieAdapter: MovieAdapter
    private val movieViewModel by viewModels<MovieViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentMovieBinding.bind(view)

        movieAdapter = MovieAdapter {
            Intent(context, DetailActivity::class.java).apply {
                putExtra(DetailActivity.EXTRA_ID, it.id)
                putExtra(DetailActivity.EXTRA_MOVIE, 1)
                startActivity(this)
            }
        }
        binding.rvMovie.layoutManager = LinearLayoutManager(context)
        binding.rvMovie.adapter = movieAdapter

        movieViewModel.getMovies().observe(viewLifecycleOwner, {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBar.visibility = View.VISIBLE
                }
                is Resource.Success -> {
                    movieAdapter.submitList(it.data)
                    binding.progressBar.visibility = View.GONE
                }
                is Resource.Error -> {
                    Toast.makeText(activity, it.message, Toast.LENGTH_LONG).show()
                    binding.progressBar.visibility = View.GONE
                }
            }
        })
    }
}