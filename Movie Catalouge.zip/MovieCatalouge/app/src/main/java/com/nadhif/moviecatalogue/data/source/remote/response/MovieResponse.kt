package com.nadhif.moviecatalogue.data.source.remote.response

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

data class MovieResponse(
        val page: Int,
        val results: List<Movie>
)

@Parcelize
data class Movie(
        @SerializedName("backdrop_path")
        val backdropPath: String?,
        val id: Long,
        val overview: String?,
        @SerializedName("poster_path")
        val posterPath: String?,
        @SerializedName("release_date")
        val releaseDate: String?,
        val title: String?,
) : Parcelable