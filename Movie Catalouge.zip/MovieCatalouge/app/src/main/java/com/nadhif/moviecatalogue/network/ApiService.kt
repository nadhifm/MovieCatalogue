package com.nadhif.moviecatalogue.network

import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.data.source.remote.response.MovieResponse
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.data.source.remote.response.TvShowResponse
import com.nadhif.moviecatalogue.utils.Constants.Companion.API_KEY
import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("movie/popular")
    fun getPopularMovieAsync(
        @Query("api_key") api_key: String = API_KEY,
        @Query("page") page: Int?
    ): Deferred<MovieResponse>

    @GET("tv/popular")
    fun getPopularTvShowAsync(
        @Query("api_key") api_key: String = API_KEY,
        @Query("page") page: Int?
    ): Deferred<TvShowResponse>

    @GET("movie/{movie_id}")
    fun getDetailMovieAsync(
        @Path("movie_id") id: Long,
        @Query("api_key") api_key: String = API_KEY
    ): Deferred<Movie>

    @GET("tv/{tv_id}")
    fun getDetailTvShowAsync(
        @Path("tv_id") id: Long,
        @Query("api_key") api_key: String = API_KEY
    ): Deferred<TvShow>
}

