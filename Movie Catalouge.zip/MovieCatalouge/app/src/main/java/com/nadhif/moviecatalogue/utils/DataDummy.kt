package com.nadhif.moviecatalogue.utils

import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.data.source.remote.response.MovieResponse
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.data.source.remote.response.TvShowResponse

object DataDummy {

    fun generateDummyRemoteMovie(): MovieResponse {
        val movies = ArrayList<Movie>()
        movies.add(
            Movie(
                "/ckfwfLkl0CkafTasoRw5FILhZAS.jpg",
                602211,
                "A rowdy, unorthodox Santa Claus is fighting to save his declining business. Meanwhile, Billy, a neglected and precocious 12 year old, hires a hit man to kill Santa after receiving a lump of coal in his stocking.",
                "/4n8QNNdk4BOX9Dslfbz5Dy6j1HK.jpg",
                "2020-11-13",
                "Fatman"
            )
        )

        return MovieResponse(1, movies)
    }

    fun generateDummyRemoteTvShow(): TvShowResponse {
        val tvShows = ArrayList<TvShow>()
        tvShows.add(
            TvShow(
                82856,
                "2019-11-12",
                "The Mandalorian",
                "After the fall of the Galactic Empire, lawlessness has spread throughout the galaxy. A lone gunfighter makes his way through the outer reaches, earning his keep as a bounty hunter.",
                "/sWgBv7LV2PRoQgkxwlibdGXKz1S.jpg",
                "/9ijMGlJKqcslswWUzTEwScm82Gs.jpg"
            )
        )

        return TvShowResponse(1, tvShows)
    }
}