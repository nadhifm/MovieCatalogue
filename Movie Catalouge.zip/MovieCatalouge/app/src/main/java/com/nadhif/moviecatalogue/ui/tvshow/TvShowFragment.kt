package com.nadhif.moviecatalogue.ui.tvshow

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.nadhif.moviecatalogue.R
import com.nadhif.moviecatalogue.adapter.TvShowAdapter
import com.nadhif.moviecatalogue.databinding.FragmentTvShowBinding
import com.nadhif.moviecatalogue.ui.detail.DetailActivity
import com.nadhif.moviecatalogue.utils.Resource
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TvShowFragment : Fragment(R.layout.fragment_tv_show) {

    private lateinit var binding: FragmentTvShowBinding
    private lateinit var tvShowAdapter: TvShowAdapter
    private val tvShowViewModel by viewModels<TvShowViewModel>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding = FragmentTvShowBinding.bind(view)

        tvShowAdapter = TvShowAdapter {
            Intent(context, DetailActivity::class.java).apply {
                putExtra(DetailActivity.EXTRA_ID, it.id)
                putExtra(DetailActivity.EXTRA_TV_SHOW, 1)
                startActivity(this)
            }
        }
        binding.rvTvShow.layoutManager = LinearLayoutManager(context)
        binding.rvTvShow.adapter = tvShowAdapter

        tvShowViewModel.getTvShows().observe(viewLifecycleOwner, {
            when(it) {
                is Resource.Loading -> {
                    binding.progressBarTvShow.visibility = View.VISIBLE
                }
                is Resource.Success -> {
                    tvShowAdapter.submitList(it.data)
                    binding.progressBarTvShow.visibility = View.GONE
                }
                is Resource.Error -> {
                    Toast.makeText(activity, it.message, Toast.LENGTH_LONG).show()
                    binding.progressBarTvShow.visibility = View.GONE
                }
            }
        })
    }
}