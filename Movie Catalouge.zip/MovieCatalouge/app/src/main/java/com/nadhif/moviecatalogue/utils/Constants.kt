package com.nadhif.moviecatalogue.utils

class Constants {

    companion object {
        const val BASE_URL = "https://api.themoviedb.org/3/"
        const val API_KEY = "c295ea727d33eec70c929e1c5e5d67fc"
        const val IMAGE_URL = "https://image.tmdb.org/t/p/w500"
    }

}