package com.nadhif.moviecatalogue.data.source.remote.response


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

data class TvShowResponse(
    val page: Int,
    val results: List<TvShow>
)

@Parcelize
data class TvShow(
    val id: Long,
    @SerializedName("first_air_date")
    val firstAirDate: String,
    val name: String,
    val overview: String,
    @SerializedName("poster_path")
    val posterPath: String?,
    @SerializedName("backdrop_path")
    val backdropPath: String?
) : Parcelable