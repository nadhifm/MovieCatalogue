package com.nadhif.moviecatalogue.ui.detail

import androidx.hilt.Assisted
import androidx.hilt.lifecycle.ViewModelInject
import androidx.lifecycle.*
import com.nadhif.moviecatalogue.data.source.remote.RemoteDataSource
import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.utils.Resource
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.IOException

class DetailViewModel @ViewModelInject constructor(
        private val repository: RemoteDataSource,
        @Assisted private val savedStateHandle: SavedStateHandle
) : ViewModel() {
    private var selectedId = savedStateHandle.get<Long>("extra_id")

    private var currentJob: Job? = null

    private val _movie = MutableLiveData<Resource<Movie>>()
    val movie: LiveData<Resource<Movie>>
        get() = _movie

    private val _tvShow = MutableLiveData<Resource<TvShow>>()
    val tvShow: LiveData<Resource<TvShow>>
        get() = _tvShow

   fun getMovies() {
        currentJob?.cancel()
        currentJob = viewModelScope.launch {
            _movie.value = Resource.Loading
            val response = repository.getDetailMovie(selectedId!!)
            try {
                _movie.value = Resource.Success(response)
            }catch (e: IOException) {
                _movie.value = Resource.Error(e.message!!)
            }
        }
    }

    fun getTvShows() {
        currentJob?.cancel()
        currentJob = viewModelScope.launch {
            _tvShow.value = Resource.Loading
            val response = repository.getDetailTvShow(selectedId!!)
            try {
                _tvShow.value = Resource.Success(response)
            }catch (e: IOException) {
                _tvShow.value = Resource.Error(e.message!!)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        currentJob?.cancel()
    }
}