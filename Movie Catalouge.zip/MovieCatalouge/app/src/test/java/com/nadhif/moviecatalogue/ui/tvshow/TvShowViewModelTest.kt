package com.nadhif.moviecatalogue.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.viewModelScope
import com.nadhif.moviecatalogue.data.CatalogueRepository
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.utils.DataDummy
import com.nadhif.moviecatalogue.utils.Resource
import com.nhaarman.mockitokotlin2.verify
import kotlinx.coroutines.*
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@ObsoleteCoroutinesApi
@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {

    private val mainThreadSurrogate = newSingleThreadContext("UI thread")
    private lateinit var viewModel: TvShowViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogueRepository: CatalogueRepository

    @Mock
    private lateinit var observer: Observer<Resource<List<TvShow>>>

    @Before
    fun setup() {
        viewModel = TvShowViewModel(catalogueRepository)
        Dispatchers.setMain(mainThreadSurrogate)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain() // reset main dispatcher to the original Main dispatcher
        mainThreadSurrogate.close()
    }

    @Test
    fun getTvShows() {
        viewModel.viewModelScope.launch {
            val dummyTvShow = DataDummy.generateDummyRemoteTvShow()
            val tvShow = MutableLiveData<Resource<List<TvShow>>>()
            tvShow.value = Resource.Success(dummyTvShow.results)

            Mockito.`when`(catalogueRepository.getTvShows(this)).thenReturn(tvShow)
            val movieEntities = viewModel.getTvShows()
            verify(catalogueRepository).getTvShows(this)
            assertNotNull(movieEntities)

            viewModel.getTvShows().observeForever(observer)
            Mockito.verify(observer).onChanged(tvShow.value)
        }
    }
}