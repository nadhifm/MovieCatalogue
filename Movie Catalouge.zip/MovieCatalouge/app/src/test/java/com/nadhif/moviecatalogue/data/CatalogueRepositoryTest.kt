package com.nadhif.moviecatalogue.data

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.nadhif.moviecatalogue.data.source.remote.RemoteDataSource
import com.nadhif.moviecatalogue.utils.DataDummy
import com.nadhif.moviecatalogue.utils.LiveDataTestUtil
import com.nadhif.moviecatalogue.utils.Resource
import com.nhaarman.mockitokotlin2.verify
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertNotNull
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito.`when`
import org.mockito.Mockito.mock
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class CatalogueRepositoryTest {

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val  remoteDataSource = mock(RemoteDataSource::class.java)
    private val fakeCatalogueRepository = FakeCatalogueRepository(remoteDataSource)

    private val movieResponse = DataDummy.generateDummyRemoteMovie()
    private val tvResponse = DataDummy.generateDummyRemoteTvShow()
    

    @Test
    fun getMovies() {
        runBlockingTest {
            `when`(remoteDataSource.getPopularMovie(1)).thenReturn(movieResponse)
            val movieEntity = LiveDataTestUtil.getValue(fakeCatalogueRepository.getMovies(this))
            verify(remoteDataSource).getPopularMovie(1)
            val movie = Resource.Success(movieResponse.results)
            assertNotNull(movieEntity)
            assertEquals(movie, movieEntity)
        }
    }

    @Test
    fun getTvShows() {
        runBlockingTest {
            `when`(remoteDataSource.getPopularTvShow(1)).thenReturn(tvResponse)
            val movieEntity = LiveDataTestUtil.getValue(fakeCatalogueRepository.getTvShows(this))
            verify(remoteDataSource).getPopularTvShow(1)
            val tvShow = Resource.Success(tvResponse.results)
            assertNotNull(movieEntity)
            assertEquals(tvShow, movieEntity)
        }
    }
}