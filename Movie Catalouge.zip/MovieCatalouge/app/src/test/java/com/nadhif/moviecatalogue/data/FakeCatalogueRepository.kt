package com.nadhif.moviecatalogue.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.nadhif.moviecatalogue.data.source.remote.RemoteDataSource
import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.data.source.remote.response.TvShow
import com.nadhif.moviecatalogue.utils.Resource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.IOException

class FakeCatalogueRepository(private val remoteDataSource: RemoteDataSource) : CatalogueDataSource {
    private var currentJob: Job? = null

    override fun getMovies(viewModelScope: CoroutineScope): LiveData<Resource<List<Movie>>> {
        currentJob?.cancel()
        val movies = MutableLiveData<Resource<List<Movie>>>()
        currentJob = viewModelScope.launch {
            movies.value = Resource.Loading
            val response = remoteDataSource.getPopularMovie(1)
            try {
                movies.value = Resource.Success(response.results)
            }catch (e: IOException) {
                movies.value = Resource.Error(e.message!!)
            }
        }

        return movies
    }

    override fun getTvShows(viewModelScope: CoroutineScope): LiveData<Resource<List<TvShow>>> {
        currentJob?.cancel()
        val tvShow = MutableLiveData<Resource<List<TvShow>>>()
        currentJob = viewModelScope.launch {
            tvShow.value = Resource.Loading
            val response = remoteDataSource.getPopularTvShow(1)
            try {
                tvShow.value = Resource.Success(response.results)
            }catch (e: IOException) {
                tvShow.value = Resource.Error(e.message!!)
            }
        }
        return tvShow
    }

    override fun cancelJob() {
        currentJob?.cancel()
    }
}