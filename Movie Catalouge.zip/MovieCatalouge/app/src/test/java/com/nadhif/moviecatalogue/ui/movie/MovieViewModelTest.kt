package com.nadhif.moviecatalogue.ui.movie

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.viewModelScope
import com.nadhif.moviecatalogue.data.CatalogueRepository
import com.nadhif.moviecatalogue.data.source.remote.response.Movie
import com.nadhif.moviecatalogue.utils.DataDummy
import com.nadhif.moviecatalogue.utils.Resource
import kotlinx.coroutines.*
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.`when`
import org.mockito.Mockito.verify
import org.mockito.junit.MockitoJUnitRunner

@ObsoleteCoroutinesApi
@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class MovieViewModelTest {

    private val mainThreadSurrogate = newSingleThreadContext("UI thread")
    private lateinit var viewModel: MovieViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogueRepository: CatalogueRepository

    @Mock
    private lateinit var observer: Observer<Resource<List<Movie>>>

    @Before
    fun setup() {
        viewModel = MovieViewModel(catalogueRepository)
        Dispatchers.setMain(mainThreadSurrogate)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain() // reset main dispatcher to the original Main dispatcher
        mainThreadSurrogate.close()
    }

    @Test
    fun getMovies() {
        viewModel.viewModelScope.launch {
            val dummyMovie = DataDummy.generateDummyRemoteMovie()
            val movie = MutableLiveData<Resource<List<Movie>>>()
            movie.value = Resource.Success(dummyMovie.results)

            `when`(catalogueRepository.getMovies(this)).thenReturn(movie)
            val movieEntities = viewModel.getMovies()
            verify(catalogueRepository).getMovies(this)
            assertNotNull(movieEntities)

            viewModel.getMovies().observeForever(observer)
            verify(observer).onChanged(movie.value)
        }
    }
}